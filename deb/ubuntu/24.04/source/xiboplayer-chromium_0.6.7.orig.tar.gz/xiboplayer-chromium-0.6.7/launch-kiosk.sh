#!/usr/bin/env bash
# =============================================================================
# Xibo Player — Self-contained Chromium Kiosk
#
# Starts a local Node.js server that serves the bundled PWA player and proxies
# CMS API requests, then launches Chromium in kiosk mode pointing at localhost.
#
# The PWA player files and server are bundled in the RPM — no external PWA
# server is needed. The PWA setup page handles CMS registration on first run.
# =============================================================================

set -euo pipefail

CONFIG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/xiboplayer/chromium"
CONFIG_FILE="${CONFIG_DIR}/config.json"
LOCK_FILE="/tmp/xiboplayer-kiosk.lock"
SERVER_PID_FILE="/tmp/xiboplayer-server.pid"

# Installed paths (RPM/DEB layout)
SERVER_DIR="/usr/libexec/xiboplayer-chromium/server"

# Server defaults (overridden by config.json "serverPort" or --port=XXXX)
SERVER_PORT=8766

# ---------------------------------------------------------------------------
# Defaults (overridden by config.json)
# ---------------------------------------------------------------------------
BROWSER="chromium"
EXTRA_BROWSER_FLAGS=""
KIOSK_MODE="true"
FULLSCREEN="true"
HIDE_MOUSE_CURSOR="true"
PREVENT_SLEEP="true"
WINDOW_WIDTH="1920"
WINDOW_HEIGHT="1080"

# ---------------------------------------------------------------------------
# Load configuration (JSON via jq)
# ---------------------------------------------------------------------------
if ! command -v jq &>/dev/null; then
    echo "[xiboplayer] ERROR: jq is required. Install: sudo dnf install jq" >&2
    exit 1
fi

# Read a JSON key from config, setting the named shell variable if present.
cfg_read() {
    local varname="$1" key="$2" file="$3"
    local val
    val=$(jq -r ".$key // empty" "$file" 2>/dev/null) || true
    [[ -n "$val" ]] && printf -v "$varname" '%s' "$val" || true
}

load_config() {
    local file="$1"
    cfg_read BROWSER            browser            "$file"
    cfg_read EXTRA_BROWSER_FLAGS extraBrowserFlags  "$file"
    cfg_read SERVER_PORT        serverPort         "$file"
    cfg_read GOOGLE_GEO_API_KEY googleGeoApiKey    "$file"
    cfg_read KIOSK_MODE         kioskMode          "$file"
    cfg_read FULLSCREEN         fullscreen         "$file"
    cfg_read HIDE_MOUSE_CURSOR  hideMouseCursor    "$file"
    cfg_read PREVENT_SLEEP      preventSleep       "$file"
    cfg_read WINDOW_WIDTH       width              "$file"
    cfg_read WINDOW_HEIGHT      height             "$file"
    cfg_read LOG_LEVEL          logLevel           "$file"
    cfg_read RELAX_SSL_CERTS    relaxSslCerts      "$file"
}

if [[ -f "$CONFIG_FILE" ]]; then
    load_config "$CONFIG_FILE"
else
    # First run — create config directory (PWA setup page handles CMS registration)
    mkdir -p "$CONFIG_DIR"
    if [[ -f /usr/share/xiboplayer-chromium/config.json ]]; then
        cp /usr/share/xiboplayer-chromium/config.json "$CONFIG_FILE"
        echo "[xiboplayer] Created default config at $CONFIG_FILE" >&2
    fi
fi

# CLI overrides
INSTANCE=""
for arg in "$@"; do
    case "$arg" in
        --port=*) SERVER_PORT="${arg#*=}" ;;
        --instance=*) INSTANCE="${arg#*=}" ;;
        --server-dir=*) SERVER_DIR="${arg#*=}" ;;
        --pwa-path=*) PWA_PATH="${arg#*=}" ;;
        --no-kiosk) KIOSK_MODE="false" ;;
        --log-level=*) LOG_LEVEL="${arg#*=}" ;;
    esac
done

# Multi-instance support: --instance=NAME isolates config, data, lock, and PID
if [[ -n "$INSTANCE" ]]; then
    CONFIG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/xiboplayer/chromium-${INSTANCE}"
    CONFIG_FILE="${CONFIG_DIR}/config.json"
    LOCK_FILE="/tmp/xiboplayer-kiosk-${INSTANCE}.lock"
    SERVER_PID_FILE="/tmp/xiboplayer-server-${INSTANCE}.pid"
    # Re-read config from the instance-specific path
    if [[ -f "$CONFIG_FILE" ]]; then
        load_config "$CONFIG_FILE"
    else
        mkdir -p "$CONFIG_DIR"
    fi
fi
PLAYER_URL="http://localhost:${SERVER_PORT}/player/"
[[ -n "${LOG_LEVEL:-}" ]] && PLAYER_URL="${PLAYER_URL}?logLevel=${LOG_LEVEL}"

# No cmsUrl in config.json → unconfigured. Wipe stale browser data so
# the PWA shows the setup screen instead of booting from ghost config.
DATA_SUFFIX="chromium"
[[ -n "$INSTANCE" ]] && DATA_SUFFIX="chromium-${INSTANCE}"
DATA_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/xiboplayer/${DATA_SUFFIX}"
CMS_URL=$(jq -r '.cmsUrl // empty' "$CONFIG_FILE" 2>/dev/null) || true
if [[ -z "$CMS_URL" && -d "$DATA_DIR" ]]; then
    rm -rf "$DATA_DIR/Default/Local Storage" \
           "$DATA_DIR/Default/IndexedDB" \
           "$DATA_DIR/Default/Service Worker" \
           "$DATA_DIR/Default/Cache" \
           "$DATA_DIR/Default/Code Cache" 2>/dev/null || true
    echo "[xiboplayer] Unconfigured — cleared stale browser data" >&2
fi

# ---------------------------------------------------------------------------
# Locking — prevent duplicate instances
# ---------------------------------------------------------------------------
cleanup() {
    local exit_code=$?
    # Disable trap to prevent re-entry when killing process group
    trap - EXIT INT TERM HUP
    echo "[xiboplayer] Shutting down (exit code: $exit_code)..." >&2
    # Stop the local server
    if [[ -f "$SERVER_PID_FILE" ]]; then
        local srv_pid
        srv_pid=$(cat "$SERVER_PID_FILE" 2>/dev/null || echo "")
        if [[ -n "$srv_pid" ]] && kill -0 "$srv_pid" 2>/dev/null; then
            kill "$srv_pid" 2>/dev/null || true
            echo "[xiboplayer] Stopped local server (PID $srv_pid)." >&2
        fi
        rm -f "$SERVER_PID_FILE"
    fi
    rm -f "$LOCK_FILE"
    restore_screen_blanking
    # Kill any child processes in our process group
    kill -- -$$ 2>/dev/null || true
    exit "$exit_code"
}

if [[ -f "$LOCK_FILE" ]]; then
    OLD_PID=$(cat "$LOCK_FILE" 2>/dev/null || echo "")
    if [[ -n "$OLD_PID" ]] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "[xiboplayer] Already running (PID $OLD_PID). Exiting." >&2
        exit 1
    fi
    echo "[xiboplayer] Stale lock file found, removing." >&2
    rm -f "$LOCK_FILE"
fi

echo $$ > "$LOCK_FILE"
trap cleanup EXIT INT TERM HUP

# ---------------------------------------------------------------------------
# Disable screen blanking / DPMS
# ---------------------------------------------------------------------------
disable_screen_blanking() {
    if [[ -n "${WAYLAND_DISPLAY:-}" ]]; then
        if command -v gsettings &>/dev/null; then
            gsettings set org.gnome.desktop.session idle-delay 0 2>/dev/null || true
            gsettings set org.gnome.desktop.screensaver lock-enabled false 2>/dev/null || true
            gsettings set org.gnome.desktop.screensaver idle-activation-enabled false 2>/dev/null || true
            echo "[xiboplayer] Disabled GNOME screen blanking (Wayland)." >&2
        fi
        if command -v kwriteconfig5 &>/dev/null; then
            kwriteconfig5 --file powermanagementprofilesrc \
                --group AC --group DPMSControl --key idleTime 0 2>/dev/null || true
            echo "[xiboplayer] Disabled KDE screen blanking (Wayland)." >&2
        fi
    fi

    if [[ -n "${DISPLAY:-}" ]]; then
        if command -v xset &>/dev/null; then
            xset s off 2>/dev/null || true
            xset s noblank 2>/dev/null || true
            xset -dpms 2>/dev/null || true
            echo "[xiboplayer] Disabled X11 screen blanking (xset)." >&2
        fi
    fi
}

restore_screen_blanking() {
    if [[ -n "${DISPLAY:-}" ]] && command -v xset &>/dev/null; then
        xset +dpms 2>/dev/null || true
        xset s on 2>/dev/null || true
    fi
}

# ---------------------------------------------------------------------------
# Resolve browser binary
# ---------------------------------------------------------------------------
resolve_browser() {
    local browser_lower
    browser_lower=$(echo "$BROWSER" | tr '[:upper:]' '[:lower:]')

    case "$browser_lower" in
        chromium|chromium-browser)
            for bin in chromium-browser chromium; do
                if command -v "$bin" &>/dev/null; then
                    echo "$bin"
                    return
                fi
            done
            # Fallback: config says chromium but only chrome is installed
            for bin in google-chrome-stable google-chrome; do
                if command -v "$bin" &>/dev/null; then
                    echo "$bin"
                    return
                fi
            done
            ;;
        chrome|google-chrome|google-chrome-stable)
            for bin in google-chrome-stable google-chrome chrome; do
                if command -v "$bin" &>/dev/null; then
                    echo "$bin"
                    return
                fi
            done
            ;;
        *)
            if command -v "$browser_lower" &>/dev/null; then
                echo "$browser_lower"
                return
            fi
            ;;
    esac

    echo ""
}

# ---------------------------------------------------------------------------
# Start local server
# ---------------------------------------------------------------------------
start_server() {
    if ! command -v node &>/dev/null; then
        echo "[xiboplayer] ERROR: Node.js is required. Install: sudo dnf install nodejs" >&2
        exit 1
    fi

    local server_args=(--port="$SERVER_PORT")
    [[ -n "${PWA_PATH:-}" ]] && server_args+=(--pwa-path="$PWA_PATH")

    echo "[xiboplayer] Starting local server on port $SERVER_PORT..." >&2
    node "$SERVER_DIR/server.js" "${server_args[@]}" &
    local srv_pid=$!
    echo "$srv_pid" > "$SERVER_PID_FILE"

    # Wait for server to be ready (up to 10 seconds)
    local retries=0
    while (( retries < 50 )); do
        if curl -s -o /dev/null "http://localhost:${SERVER_PORT}/" 2>/dev/null; then
            echo "[xiboplayer] Server ready (PID $srv_pid)." >&2
            return 0
        fi
        # Check if server process died
        if ! kill -0 "$srv_pid" 2>/dev/null; then
            echo "[xiboplayer] ERROR: Server process died." >&2
            return 1
        fi
        sleep 0.2
        retries=$((retries + 1))
    done

    echo "[xiboplayer] ERROR: Server did not start within 10 seconds." >&2
    kill "$srv_pid" 2>/dev/null || true
    return 1
}

# ---------------------------------------------------------------------------
# Build Chromium arguments
# ---------------------------------------------------------------------------
build_chromium_args() {
    BROWSER_ARGS=(
        --no-first-run
        --disable-translate
        --disable-infobars
        --disable-suggestions-service
        --disable-save-password-bubble
        --disable-session-crashed-bubble
        --disable-component-update
        --noerrdialogs
        --disable-pinch
        --overscroll-history-navigation=0
        --autoplay-policy=no-user-gesture-required
        --check-for-update-interval=31536000
        --disable-features=TranslateUI,Translate
        --disable-ipc-flooding-protection
        --password-store=basic
        --lang=en-US
        "--auto-select-desktop-capture-source=Entire screen"
        --auto-accept-this-tab-capture
        # Prevent GPU crash and renderer freeze when screen is locked/off
        --disable-gpu-watchdog
        --disable-background-timer-throttling
        --disable-renderer-backgrounding
    )

    # Kiosk / fullscreen / window size
    if [[ "$KIOSK_MODE" == "true" ]]; then
        BROWSER_ARGS=(--kiosk "${BROWSER_ARGS[@]}")
    else
        [[ "$FULLSCREEN" == "true" ]] && BROWSER_ARGS+=(--start-fullscreen)
        BROWSER_ARGS+=(--window-size="${WINDOW_WIDTH},${WINDOW_HEIGHT}")
    fi

    # XDG-compliant profile directory (instance-aware)
    BROWSER_ARGS+=(--user-data-dir="$DATA_DIR")

    # Accept invalid SSL certificates for media/stream URLs (default: true)
    # Self-signed certs on media streams are common in signage deployments.
    # Set "relaxSslCerts": false in config.json to enforce strict SSL.
    if [[ "${RELAX_SSL_CERTS:-true}" == "true" ]]; then
        BROWSER_ARGS+=(--ignore-certificate-errors --test-type)
        echo "[xiboplayer]   SSL:     relaxed (--ignore-certificate-errors)" >&2
    fi

    # Adaptive memory tuning based on device RAM and CPU count
    # Same tiers as Electron (main.js) and SW (calculateChunkConfig)
    local total_ram_kb total_ram_gb cpu_count max_old_space_mb raster_threads
    total_ram_kb=$(awk '/^MemTotal:/ { print $2 }' /proc/meminfo)
    total_ram_gb=$(( (total_ram_kb + 524288) / 1048576 ))  # round to nearest GB
    cpu_count=$(nproc 2>/dev/null || echo 2)

    if (( total_ram_gb <= 1 )); then
        max_old_space_mb=128; raster_threads=1
    elif (( total_ram_gb <= 2 )); then
        max_old_space_mb=192; raster_threads=2
    elif (( total_ram_gb <= 4 )); then
        max_old_space_mb=256; raster_threads=$(( cpu_count < 2 ? cpu_count : 2 ))
    else
        max_old_space_mb=384; raster_threads=$(( cpu_count < 4 ? cpu_count : 4 ))
    fi

    BROWSER_ARGS+=(
        --js-flags="--max-old-space-size=${max_old_space_mb}"
        --num-raster-threads="$raster_threads"
        --gpu-rasterization-msaa-sample-count=0
    )
    echo "[xiboplayer]   Memory:  ${total_ram_gb}GB RAM, ${cpu_count} CPUs → V8 heap ${max_old_space_mb}MB, ${raster_threads} raster threads" >&2

    # Append any user-defined extra flags
    if [[ -n "$EXTRA_BROWSER_FLAGS" ]]; then
        local -a extra
        read -ra extra <<< "$EXTRA_BROWSER_FLAGS"
        BROWSER_ARGS+=("${extra[@]}")
    fi

    # URL must be last — point at local server, not remote CMS
    BROWSER_ARGS+=("$PLAYER_URL")
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
main() {
    echo "[xiboplayer] Starting Xibo Player (self-contained)" >&2
    [[ -n "$INSTANCE" ]] && echo "[xiboplayer]   Instance: $INSTANCE" >&2
    echo "[xiboplayer]   Browser: $BROWSER" >&2
    echo "[xiboplayer]   Server:  http://localhost:$SERVER_PORT" >&2
    echo "[xiboplayer]   Kiosk:   $KIOSK_MODE  Fullscreen: $FULLSCREEN  Sleep: $PREVENT_SLEEP  Cursor: $([[ $HIDE_MOUSE_CURSOR == true ]] && echo hidden || echo visible)" >&2

    # Wait for display to be available (important for systemd startup)
    local retries=0
    while [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]] && (( retries < 30 )); do
        echo "[xiboplayer] Waiting for display server... (attempt $((retries+1))/30)" >&2
        sleep 2
        retries=$((retries + 1))
    done

    if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]]; then
        echo "[xiboplayer] ERROR: No display server available after 60 seconds." >&2
        exit 1
    fi

    # Disable screen blanking (if configured)
    if [[ "$PREVENT_SLEEP" == "true" ]]; then
        disable_screen_blanking
    fi

    # Hide mouse cursor (if configured)
    if [[ "$HIDE_MOUSE_CURSOR" == "true" ]]; then
        if command -v unclutter &>/dev/null; then
            unclutter --timeout 1 --jitter 2 --hide-on-touch &
            echo "[xiboplayer] Mouse cursor hidden (unclutter)." >&2
        else
            echo "[xiboplayer] WARNING: unclutter not found, cursor will be visible." >&2
            echo "[xiboplayer]   Install: sudo dnf install unclutter" >&2
        fi
    fi

    # Start the local server (serves PWA + proxies CMS)
    start_server || exit 1

    # Resolve browser binary
    local browser_bin
    browser_bin=$(resolve_browser)
    if [[ -z "$browser_bin" ]]; then
        echo "[xiboplayer] ERROR: Browser '$BROWSER' not found." >&2
        echo "[xiboplayer]   Install: sudo dnf install chromium" >&2
        exit 1
    fi
    echo "[xiboplayer]   Binary:  $browser_bin" >&2

    # Create profile directory and kiosk policies
    mkdir -p "$DATA_DIR/policies/managed" 2>/dev/null || true
    cat > "$DATA_DIR/policies/managed/kiosk.json" << POLICY
{
  "TranslateEnabled": false,
  "AutoFillEnabled": false,
  "PasswordManagerEnabled": false,
  "SearchSuggestEnabled": false,
  "MetricsReportingEnabled": false,
  "SpellCheckServiceEnabled": false,
  "DownloadRestrictions": 3,
  "DefaultGeolocationSetting": 1,
  "VideoCaptureAllowed": true,
  "AudioCaptureAllowed": true,
  "VideoCaptureAllowedUrls": ["http://localhost:${SERVER_PORT}"],
  "AudioCaptureAllowedUrls": ["http://localhost:${SERVER_PORT}"],
  "ScreenCaptureAllowed": true,
  "ScreenCaptureAllowedByOrigins": ["http://localhost:${SERVER_PORT}"],
  "TabCaptureAllowedByOrigins": ["http://localhost:${SERVER_PORT}"],
  "RestoreOnStartup": 4,
  "RestoreOnStartupURLs": []
}
POLICY

    # Suppress "Chrome didn't shut down correctly" restore dialog.
    # Flags (--disable-session-crashed-bubble, --noerrdialogs) don't reliably
    # suppress the infobar. Patching the Preferences file on every launch does.
    local prefs_file="$DATA_DIR/Default/Preferences"
    if [[ -f "$prefs_file" ]]; then
        # Use sed to patch exit_type and exited_cleanly in-place
        sed -i 's/"exit_type":"[^"]*"/"exit_type":"Normal"/g; s/"exited_cleanly":false/"exited_cleanly":true/g' "$prefs_file"
    fi

    # Export Google Geolocation API key for the SDK (if configured)
    if [[ -n "${GOOGLE_GEO_API_KEY:-}" ]]; then
        export GOOGLE_GEO_API_KEY
        echo "[xiboplayer]   Geo API: configured" >&2
    fi

    # Build arguments and launch
    build_chromium_args

    echo "[xiboplayer]   Args:    ${BROWSER_ARGS[*]}" >&2
    echo "[xiboplayer] Launching browser..." >&2

    # Execute the browser — this blocks until the browser exits.
    "$browser_bin" "${BROWSER_ARGS[@]}"
}

main "$@"
