# Electron Player Configuration

Configuration file: `~/.config/xiboplayer/electron/config.json`

## Full Reference

```jsonc
{
  // CMS connection — set via Setup screen (S key) or here
  "cmsUrl": "https://cms.example.com",
  "cmsKey": "your-server-key",
  "displayName": "Lobby Screen 1",

  // Local server port (default: 8765)
  "serverPort": 8765,

  // Window and display
  "kioskMode": true,
  "fullscreen": true,
  "hideMouseCursor": true,
  "preventSleep": true,
  "width": 1920,
  "height": 1080,

  // Auto-launch on login
  "autoLaunch": false,

  // CMS transport: "auto" (default) or "xmds" (force SOAP for unpatched Xibo CMS)
  "transport": "auto",

  // Google Geolocation API key (optional, improves location accuracy)
  "googleGeoApiKey": "",

  // Keyboard and mouse controls
  "controls": {
    "keyboard": {
      "debugOverlays": false,
      "setupKey": false,
      "playbackControl": false,
      "videoControls": false
    },
    "mouse": {
      "statusBarOnHover": false
    }
  }
}
```

## Transport

| Value | Description |
|-------|-------------|
| `"auto"` (default) | Try REST API first, fall back to SOAP if the CMS lacks REST endpoints |
| `"xmds"` | Force SOAP/XMDS transport — use this for unpatched Xibo CMS without REST API |

Omitting `transport` or setting it to any value other than `"xmds"` uses auto-detection.

## Google Geolocation API Key

Optional. Improves location accuracy from ~5 km (IP-based fallback) to ~50 m (Google API).

```json
{
  "googleGeoApiKey": "AIzaSy..."
}
```

The key is passed to the SDK via `playerConfig`. Without it, the player falls back to free IP-based geolocation providers — no key required.

## Media Capture

Webcam and microphone access is auto-approved via Electron's `setPermissionRequestHandler` (the `media` permission). No configuration needed.

## Controls

The `controls` section gates keyboard shortcuts and mouse behavior in the player. All controls default to `false` (disabled). Omitting `controls` entirely means no keyboard shortcuts or mouse hover will be active — a clean, locked-down kiosk.

### Keyboard

| Key | Group | Default | Action |
|-----|-------|---------|--------|
| `D` | `debugOverlays` | **false** | Toggle download progress overlay |
| `T` | `debugOverlays` | **false** | Toggle timeline/schedule overlay |
| `S` | `setupKey` | **false** | Toggle CMS setup screen |
| `V` | `videoControls` | **false** | Toggle native `<video>` controls |
| `ArrowRight` / `PageDown` | `playbackControl` | **false** | Skip to next layout |
| `ArrowLeft` / `PageUp` | `playbackControl` | **false** | Skip to previous layout |
| `Space` | `playbackControl` | **false** | Pause / resume playback |
| `R` | `playbackControl` | **false** | Revert to scheduled layout |
| Media keys | `playbackControl` | **false** | Next/prev/pause/play (MediaSession API) |

Set a group to `true` to enable keys in that group:

```json
{
  "controls": {
    "keyboard": {
      "setupKey": true,
      "playbackControl": true
    }
  }
}
```

### Mouse

| Setting | Default | Action |
|---------|---------|--------|
| `statusBarOnHover` | **false** | Show status bar (CMS URL, player status) when mouse hovers over the player |

Set to `true` to show the status bar during development:

```json
{
  "controls": {
    "mouse": {
      "statusBarOnHover": true
    }
  }
}
```

## Development Example

For development with all controls and debug overlays enabled:

```json
{
  "cmsUrl": "https://cms.example.com",
  "cmsKey": "your-key",
  "displayName": "Lobby-1",
  "kioskMode": true,
  "fullscreen": true,
  "hideMouseCursor": true,
  "controls": {
    "keyboard": {
      "debugOverlays": true,
      "setupKey": true,
      "playbackControl": true,
      "videoControls": true
    },
    "mouse": {
      "statusBarOnHover": true
    }
  }
}
```

## Config Flow

```
config.json
  → main.js reads controls
    → passes to @xiboplayer/proxy as playerConfig
      → proxy injects into localStorage['xibo_config'].controls
        → PWA main.ts reads controls, gates keyboard handlers
        → PWA index.html reads controls, gates hover CSS
```

Changes to `config.json` require a player restart to take effect.

## Config Templates

The `configs/` directory contains reusable config templates with variable substitution and management scripts for development and testing.

### Quick Start

```bash
# 1. Copy secrets example and fill in your CMS credentials
cp configs/secrets.env.example configs/secrets.env
vi configs/secrets.env

# 2. Apply a template to create a player instance
configs/apply.sh electron-dev electron            # dev mode with debug
configs/apply.sh electron-kiosk electron           # production kiosk
configs/apply.sh electron-sync-lead electron-sync-lead    PORT=8765
configs/apply.sh electron-sync-follower electron-sync-follower-1 PORT=8766 TOPOLOGY_X=1

# 3. Clean up an instance
configs/clean.sh electron content   # clear downloaded media only
configs/clean.sh electron browser   # clear browser caches + media
configs/clean.sh electron full      # fresh start, keep auth
configs/clean.sh electron nuke      # total wipe, new display identity
```

### Templates

| Template | Purpose |
|----------|---------|
| `electron-dev.json` | Development: no kiosk, debug logging, all overlays and controls enabled |
| `electron-kiosk.json` | Production: kiosk mode, no debug, no controls |
| `electron-sync-lead.json` | Sync wall leader: 960x540, debug, sync config |
| `electron-sync-follower.json` | Sync wall follower: configurable port, position, topology |

### Variable Syntax

Templates use `{{VAR}}` and `{{VAR:default}}` placeholders:

```jsonc
{
  "cmsUrl": "{{CMS_URL}}",              // required — error if not in secrets.env or CLI
  "displayName": "{{DISPLAY_NAME:dev}}", // optional — uses "dev" if not provided
  "serverPort": {{PORT:8765}}            // numeric defaults work too
}
```

Variables are resolved in order: CLI args > `secrets.env` > default value.

### Secrets

`configs/secrets.env` holds CMS credentials (not committed — in `.gitignore`):

```bash
CMS_URL=https://your-cms.example.com
CMS_KEY=your-server-key
API_CLIENT_ID=your-oauth-client-id       # optional: enables auto-authorization
API_CLIENT_SECRET=your-oauth-client-secret
```

### Clean Levels

| Level | Removes | Keeps |
|-------|---------|-------|
| `content` | Shared media cache | Browser state, auth, config |
| `browser` | Browser caches + content | Auth (localStorage, IndexedDB), config |
| `full` | Everything except auth | Display identity (hardwareKey, XMR keys) |
| `nuke` | Everything | Nothing — new display, needs re-authorization |
